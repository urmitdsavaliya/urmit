// ===== MAIN JAVASCRIPT FILE =====

// DOM Elements
const navbar = document.getElementById('navbar');
const navToggle = document.getElementById('nav-toggle');
const navMenu = document.getElementById('nav-menu');
const navLinks = document.querySelectorAll('.nav-link');
const loadingScreen = document.getElementById('loading-screen');
const typingText = document.getElementById('typing-text');
const contactForm = document.getElementById('contact-form');
const projectModal = document.getElementById('project-modal');
const modalClose = document.getElementById('modal-close');
const filterBtns = document.querySelectorAll('.filter-btn');
const projectCards = document.querySelectorAll('.project-card');
const skillBars = document.querySelectorAll('.skill-progress');

// ===== LOADING SCREEN =====
window.addEventListener('load', () => {
    setTimeout(() => {
        loadingScreen.classList.add('hidden');
        document.body.style.overflow = 'visible';
        
        // Initialize animations after loading
        initializeAnimations();
        createParticles();
    }, 2000);
});

// ===== NAVIGATION =====
// Mobile menu toggle
navToggle.addEventListener('click', () => {
    navToggle.classList.toggle('active');
    navMenu.classList.toggle('active');
    document.body.style.overflow = navMenu.classList.contains('active') ? 'hidden' : 'visible';
});

// Close mobile menu when clicking on a link
navLinks.forEach(link => {
    link.addEventListener('click', () => {
        navToggle.classList.remove('active');
        navMenu.classList.remove('active');
        document.body.style.overflow = 'visible';
    });
});

// Navbar scroll effect
window.addEventListener('scroll', () => {
    if (window.scrollY > 100) {
        navbar.classList.add('scrolled');
    } else {
        navbar.classList.remove('scrolled');
    }
});

// Active navigation link highlighting
const sections = document.querySelectorAll('section[id]');

const highlightNavLink = () => {
    const scrollY = window.pageYOffset;
    
    sections.forEach(section => {
        const sectionHeight = section.offsetHeight;
        const sectionTop = section.offsetTop - 100;
        const sectionId = section.getAttribute('id');
        const navLink = document.querySelector(`.nav-link[href="#${sectionId}"]`);
        
        if (scrollY > sectionTop && scrollY <= sectionTop + sectionHeight) {
            navLinks.forEach(link => link.classList.remove('active'));
            if (navLink) navLink.classList.add('active');
        }
    });
};

window.addEventListener('scroll', highlightNavLink);

// Smooth scrolling for navigation links
navLinks.forEach(link => {
    link.addEventListener('click', (e) => {
        e.preventDefault();
        const targetId = link.getAttribute('href');
        const targetSection = document.querySelector(targetId);
        
        if (targetSection) {
            const offsetTop = targetSection.offsetTop - 80;
            window.scrollTo({
                top: offsetTop,
                behavior: 'smooth'
            });
        }
    });
});

// ===== TYPING ANIMATION =====
const typingTexts = [
    'AI-Powered Developer',
    'Web & Mobile Developer',
    'Loveable Expert',
    'Cursor AI Specialist',
    'Innovation Creator'
];

let textIndex = 0;
let charIndex = 0;
let isDeleting = false;
let typingSpeed = 100;

function typeWriter() {
    const currentText = typingTexts[textIndex];
    
    if (isDeleting) {
        typingText.textContent = currentText.substring(0, charIndex - 1);
        charIndex--;
        typingSpeed = 50;
    } else {
        typingText.textContent = currentText.substring(0, charIndex + 1);
        charIndex++;
        typingSpeed = 100;
    }
    
    if (!isDeleting && charIndex === currentText.length) {
        typingSpeed = 2000;
        isDeleting = true;
    } else if (isDeleting && charIndex === 0) {
        isDeleting = false;
        textIndex = (textIndex + 1) % typingTexts.length;
        typingSpeed = 500;
    }
    
    setTimeout(typeWriter, typingSpeed);
}

// Start typing animation
setTimeout(typeWriter, 3000);

// ===== PARTICLE SYSTEM =====
function createParticles() {
    const particlesContainer = document.getElementById('particles');
    const particleCount = 50;
    
    for (let i = 0; i < particleCount; i++) {
        createParticle(particlesContainer);
    }
    
    // Continuously create new particles
    setInterval(() => {
        if (particlesContainer.children.length < particleCount) {
            createParticle(particlesContainer);
        }
    }, 300);
}

function createParticle(container) {
    const particle = document.createElement('div');
    particle.className = 'particle';
    
    // Random starting position
    particle.style.left = Math.random() * 100 + '%';
    particle.style.animationDuration = (Math.random() * 3 + 2) + 's';
    particle.style.animationDelay = Math.random() * 2 + 's';
    
    container.appendChild(particle);
    
    // Remove particle after animation
    setTimeout(() => {
        if (particle.parentNode) {
            particle.parentNode.removeChild(particle);
        }
    }, 8000);
}

// ===== INTERSECTION OBSERVER FOR ANIMATIONS =====
function initializeAnimations() {
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
                
                // Animate skill bars when skills section is visible
                if (entry.target.classList.contains('skills')) {
                    animateSkillBars();
                }
                
                // Animate stats when about section is visible
                if (entry.target.classList.contains('about')) {
                    animateStats();
                }
            }
        });
    }, observerOptions);
    
    // Observe sections for animations
    const animatedElements = document.querySelectorAll('.fade-in-up, .fade-in-left, .fade-in-right, .scale-in-center, section');
    animatedElements.forEach(el => {
        el.classList.add('fade-in-up');
        observer.observe(el);
    });
}

// ===== SKILL BARS ANIMATION =====
function animateSkillBars() {
    skillBars.forEach((bar, index) => {
        setTimeout(() => {
            const width = bar.getAttribute('data-width');
            bar.style.width = width;
        }, index * 200);
    });
}

// ===== STATS COUNTER ANIMATION =====
function animateStats() {
    const statNumbers = document.querySelectorAll('.stat-number');
    
    statNumbers.forEach(stat => {
        const target = parseInt(stat.textContent);
        const increment = target / 50;
        let current = 0;
        
        const updateCounter = () => {
            if (current < target) {
                current += increment;
                stat.textContent = Math.ceil(current) + '+';
                setTimeout(updateCounter, 40);
            } else {
                stat.textContent = target + '+';
            }
        };
        
        updateCounter();
    });
}

// ===== PROJECT FILTERING =====
filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
        // Remove active class from all buttons
        filterBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        
        const filter = btn.getAttribute('data-filter');
        
        projectCards.forEach(card => {
            const category = card.getAttribute('data-category');
            
            if (filter === 'all' || category === filter) {
                card.classList.remove('hidden');
                card.style.display = 'block';
            } else {
                card.classList.add('hidden');
                setTimeout(() => {
                    card.style.display = 'none';
                }, 300);
            }
        });
    });
});

// ===== PROJECT MODAL =====
const projectData = {
    1: {
        title: 'AI-Powered E-Commerce Platform',
        image: './assets/images/project1.jpg',
        description: 'A modern e-commerce web application built using Loveable and Cursor AI, featuring intelligent product recommendations, automated customer support, AI-powered search, and seamless user experience with advanced machine learning capabilities.',
        tech: ['Loveable', 'React', 'TypeScript', 'AI Integration', 'Stripe', 'OpenAI API'],
        features: [
            'AI-powered product recommendations',
            'Intelligent search with natural language processing',
            'Automated customer support chatbot',
            'Dynamic pricing optimization',
            'Personalized user experience',
            'Real-time inventory management',
            'Advanced analytics and insights',
            'Multi-language AI translation'
        ],
        github: 'https://github.com/example/ai-ecommerce',
        demo: 'https://example.com/ai-ecommerce-demo'
    },
    2: {
        title: 'AI-Enhanced Social Media App',
        image: './assets/images/project2.jpg',
        description: 'React Native social media application with AI-powered content moderation, smart photo tagging, personalized feed algorithms, and intelligent user matching built using Cursor AI and GitHub Copilot.',
        tech: ['React Native', 'Cursor AI', 'Firebase', 'AI/ML APIs', 'TensorFlow', 'OpenAI'],
        features: [
            'AI-powered content moderation',
            'Smart photo tagging and recognition',
            'Personalized feed algorithms',
            'Intelligent user recommendations',
            'Automated content creation assistance',
            'Real-time sentiment analysis',
            'AI-driven engagement optimization',
            'Smart notification timing'
        ],
        github: 'https://github.com/example/ai-social-app',
        demo: 'https://example.com/ai-social-demo'
    },
    3: {
        title: 'AI Fitness Coach App',
        image: './assets/images/project3.jpg',
        description: 'Intelligent fitness application with AI-powered workout recommendations, real-time form analysis using computer vision, personalized nutrition plans, and adaptive training programs built with advanced AI tools.',
        tech: ['React Native', 'AI/ML', 'TensorFlow', 'OpenAI API', 'Computer Vision', 'Health APIs'],
        features: [
            'AI-powered workout recommendations',
            'Real-time form analysis with computer vision',
            'Personalized nutrition planning',
            'Adaptive training programs',
            'Voice-activated AI coach',
            'Progress prediction and optimization',
            'Injury prevention algorithms',
            'Smart recovery recommendations'
        ],
        github: 'https://github.com/example/ai-fitness-app',
        demo: 'https://example.com/ai-fitness-demo'
    },
    4: {
        title: 'AI Analytics Dashboard',
        image: './assets/images/project4.jpg',
        description: 'Intelligent business dashboard built with Next.js and AI tools, featuring predictive analytics, automated insights generation, smart data visualization, and AI-powered business intelligence.',
        tech: ['Next.js', 'TypeScript', 'AI Analytics', 'Vercel', 'Machine Learning', 'Data APIs'],
        features: [
            'Predictive analytics and forecasting',
            'Automated insight generation',
            'AI-powered data visualization',
            'Natural language query interface',
            'Anomaly detection and alerts',
            'Smart report generation',
            'Real-time decision recommendations',
            'Intelligent data correlation'
        ],
        github: 'https://github.com/example/ai-analytics-dashboard',
        demo: 'https://example.com/ai-dashboard-demo'
    },
    5: {
        title: 'AI Code Generator',
        image: './assets/images/project5.jpg',
        description: 'Intelligent code generation tool built with AI APIs that creates React components, API endpoints, database schemas, and complete applications from natural language descriptions with advanced AI assistance.',
        tech: ['OpenAI API', 'React', 'Node.js', 'AI/ML', 'GitHub Copilot', 'Claude API'],
        features: [
            'Natural language to code conversion',
            'React component generation',
            'API endpoint creation',
            'Database schema generation',
            'Code optimization suggestions',
            'Automated testing generation',
            'Documentation creation',
            'Multi-framework support'
        ],
        github: 'https://github.com/example/ai-code-generator',
        demo: 'https://example.com/ai-code-demo'
    },
    6: {
        title: 'Smart Food Delivery Platform',
        image: './assets/images/project6.jpg',
        description: 'AI-powered food delivery web platform with intelligent recommendations, dynamic pricing optimization, automated customer service, and smart logistics built using Loveable and modern AI technologies.',
        tech: ['Loveable', 'React', 'AI Recommendations', 'Stripe', 'Machine Learning', 'Maps API'],
        features: [
            'AI-powered food recommendations',
            'Dynamic pricing optimization',
            'Intelligent delivery routing',
            'Automated customer support',
            'Predictive demand forecasting',
            'Smart inventory management',
            'Personalized promotions',
            'Real-time order optimization'
        ],
        github: 'https://github.com/example/smart-food-delivery',
        demo: 'https://example.com/smart-food-demo'
    }
};

// Open project modal
document.querySelectorAll('[data-project]').forEach(btn => {
    btn.addEventListener('click', (e) => {
        e.preventDefault();
        const projectId = btn.getAttribute('data-project');
        const project = projectData[projectId];
        
        if (project) {
            showProjectModal(project);
        }
    });
});

function showProjectModal(project) {
    document.getElementById('modal-title').textContent = project.title;
    document.getElementById('modal-image').src = project.image;
    document.getElementById('modal-description').textContent = project.description;
    document.getElementById('modal-github').href = project.github;
    document.getElementById('modal-demo').href = project.demo;
    
    // Populate tech tags
    const techContainer = document.getElementById('modal-tech');
    techContainer.innerHTML = '';
    project.tech.forEach(tech => {
        const tag = document.createElement('span');
        tag.className = 'tech-tag';
        tag.textContent = tech;
        techContainer.appendChild(tag);
    });
    
    // Populate features
    const featuresList = document.getElementById('modal-features-list');
    featuresList.innerHTML = '';
    project.features.forEach(feature => {
        const li = document.createElement('li');
        li.textContent = feature;
        featuresList.appendChild(li);
    });
    
    projectModal.classList.add('show');
    document.body.style.overflow = 'hidden';
}

// Close project modal
function closeProjectModal() {
    projectModal.classList.remove('show');
    document.body.style.overflow = 'visible';
}

modalClose.addEventListener('click', closeProjectModal);

projectModal.addEventListener('click', (e) => {
    if (e.target === projectModal) {
        closeProjectModal();
    }
});

// Close modal with Escape key
document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && projectModal.classList.contains('show')) {
        closeProjectModal();
    }
});

// ===== CONTACT FORM =====
contactForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const formData = new FormData(contactForm);
    const formStatus = document.getElementById('form-status');
    
    // Clear previous errors
    document.querySelectorAll('.form-error').forEach(error => {
        error.classList.remove('show');
    });
    
    // Validate form
    const name = formData.get('name').trim();
    const email = formData.get('email').trim();
    const subject = formData.get('subject').trim();
    const message = formData.get('message').trim();
    
    let isValid = true;
    
    if (!name) {
        showFormError('name-error', 'Name is required');
        isValid = false;
    }
    
    if (!email) {
        showFormError('email-error', 'Email is required');
        isValid = false;
    } else if (!isValidEmail(email)) {
        showFormError('email-error', 'Please enter a valid email');
        isValid = false;
    }
    
    if (!subject) {
        showFormError('subject-error', 'Subject is required');
        isValid = false;
    }
    
    if (!message) {
        showFormError('message-error', 'Message is required');
        isValid = false;
    }
    
    if (!isValid) return;
    
    // Show loading state
    const submitBtn = contactForm.querySelector('button[type="submit"]');
    const originalText = submitBtn.innerHTML;
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Sending...';
    submitBtn.disabled = true;
    
    try {
        // Simulate form submission (replace with actual endpoint)
        await new Promise(resolve => setTimeout(resolve, 2000));
        
        // Show success message
        showFormStatus('success', 'Message sent successfully! I\'ll get back to you soon.');
        contactForm.reset();
        
    } catch (error) {
        // Show error message
        showFormStatus('error', 'Failed to send message. Please try again.');
    } finally {
        // Reset button
        submitBtn.innerHTML = originalText;
        submitBtn.disabled = false;
    }
});

function showFormError(errorId, message) {
    const errorElement = document.getElementById(errorId);
    errorElement.textContent = message;
    errorElement.classList.add('show');
}

function showFormStatus(type, message) {
    const formStatus = document.getElementById('form-status');
    formStatus.textContent = message;
    formStatus.className = `form-status show ${type}`;
    
    setTimeout(() => {
        formStatus.classList.remove('show');
    }, 5000);
}

function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

// ===== SCROLL TO TOP =====
const scrollToTopBtn = document.createElement('button');
scrollToTopBtn.innerHTML = '<i class="fas fa-chevron-up"></i>';
scrollToTopBtn.className = 'scroll-to-top';
scrollToTopBtn.style.cssText = `
    position: fixed;
    bottom: 20px;
    right: 20px;
    width: 50px;
    height: 50px;
    background: var(--gradient-primary);
    border: none;
    border-radius: 50%;
    color: white;
    font-size: 1.2rem;
    cursor: pointer;
    opacity: 0;
    visibility: hidden;
    transition: all 0.3s ease;
    z-index: 1000;
    box-shadow: var(--shadow-lg);
`;

document.body.appendChild(scrollToTopBtn);

// Show/hide scroll to top button
window.addEventListener('scroll', () => {
    if (window.scrollY > 500) {
        scrollToTopBtn.style.opacity = '1';
        scrollToTopBtn.style.visibility = 'visible';
    } else {
        scrollToTopBtn.style.opacity = '0';
        scrollToTopBtn.style.visibility = 'hidden';
    }
});

// Scroll to top functionality
scrollToTopBtn.addEventListener('click', () => {
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });
});

// ===== THEME TOGGLE (Optional Enhancement) =====
function createThemeToggle() {
    const themeToggle = document.createElement('button');
    themeToggle.innerHTML = '<i class="fas fa-moon"></i>';
    themeToggle.className = 'theme-toggle';
    themeToggle.style.cssText = `
        position: fixed;
        top: 50%;
        right: 20px;
        width: 50px;
        height: 50px;
        background: var(--bg-secondary);
        border: 1px solid var(--surface-color);
        border-radius: 50%;
        color: var(--text-primary);
        font-size: 1.2rem;
        cursor: pointer;
        transition: all 0.3s ease;
        z-index: 1000;
        transform: translateY(-50%);
    `;
    
    document.body.appendChild(themeToggle);
    
    themeToggle.addEventListener('click', () => {
        document.body.classList.toggle('light-theme');
        const icon = themeToggle.querySelector('i');
        
        if (document.body.classList.contains('light-theme')) {
            icon.className = 'fas fa-sun';
        } else {
            icon.className = 'fas fa-moon';
        }
    });
}

// Initialize theme toggle (uncomment if needed)
// createThemeToggle();

// ===== PERFORMANCE OPTIMIZATIONS =====
// Debounce scroll events
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Apply debouncing to scroll events
const debouncedScrollHandler = debounce(() => {
    highlightNavLink();
}, 10);

window.addEventListener('scroll', debouncedScrollHandler);

// ===== ACCESSIBILITY ENHANCEMENTS =====
// Focus management for modal
function trapFocus(element) {
    const focusableElements = element.querySelectorAll(
        'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
    );
    const firstElement = focusableElements[0];
    const lastElement = focusableElements[focusableElements.length - 1];
    
    element.addEventListener('keydown', (e) => {
        if (e.key === 'Tab') {
            if (e.shiftKey) {
                if (document.activeElement === firstElement) {
                    lastElement.focus();
                    e.preventDefault();
                }
            } else {
                if (document.activeElement === lastElement) {
                    firstElement.focus();
                    e.preventDefault();
                }
            }
        }
    });
    
    firstElement.focus();
}

// Apply focus trap when modal opens
const originalShowProjectModal = showProjectModal;
showProjectModal = function(project) {
    originalShowProjectModal(project);
    trapFocus(projectModal);
};

// ===== ERROR HANDLING =====
window.addEventListener('error', (e) => {
    console.error('JavaScript Error:', e.error);
    // You can add error reporting here
});

// ===== INITIALIZATION =====
document.addEventListener('DOMContentLoaded', () => {
    // Add any additional initialization code here
    console.log('AI-Powered Developer Portfolio loaded successfully!');
});