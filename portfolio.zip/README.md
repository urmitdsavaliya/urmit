# AI-Powered Web & Mobile Developer Portfolio

A modern, responsive portfolio website designed for AI-powered web and mobile developers. Built with HTML5, CSS3, and JavaScript, featuring a dark theme with AI-focused branding and smooth animations, showcasing expertise in tools like Loveable, Cursor, VS Code, and other leading AI development platforms.

## 🚀 Features

### Design & UI
- **Modern Dark Theme** with Flutter blue (#0175C2) color scheme
- **Fully Responsive** design for mobile, tablet, and desktop
- **Smooth Animations** and transitions throughout
- **Interactive Elements** with hover effects and micro-interactions
- **Professional Typography** using Inter and JetBrains Mono fonts

### Sections
- **Hero Section** with typing animation and particle background
- **About Me** with professional photo and AI development statistics
- **Skills** with animated progress bars for AI tools and modern technologies
- **Projects Showcase** with filterable AI-powered projects and modal details
- **Experience Timeline** with AI-powered development journey
- **Contact Form** with validation and modern styling

### Interactive Features
- **Typing Animation** for hero section subtitle
- **Smooth Scrolling** navigation with active link highlighting
- **Mobile-Friendly** hamburger menu
- **Project Filtering** by category (Web Apps, Mobile Apps, AI-Powered)
- **Modal Windows** for detailed project information
- **Form Validation** with real-time feedback
- **Particle System** for visual enhancement
- **Loading Screen** with AI-themed logo animation

### Performance & Accessibility
- **Optimized Performance** with debounced scroll events
- **Accessibility Features** including focus management and ARIA labels
- **SEO Optimized** with meta tags and semantic HTML
- **Cross-Browser Compatible** with modern web standards
- **Reduced Motion Support** for users with motion sensitivity

## 📁 Project Structure

```
ai-developer-portfolio/
├── index.html              # Main HTML file
├── css/
│   ├── style.css          # Main stylesheet with dark theme
│   └── animations.css     # Animation definitions and effects
├── js/
│   ├── main.js           # Core functionality and interactions
│   └── animations.js     # Advanced animation controllers
├── assets/
│   ├── images/           # Portfolio images and screenshots
│   └── icons/            # Favicon and icon files
└── README.md             # Project documentation
```

## 🛠️ Technologies Used

- **HTML5** - Semantic markup and structure
- **CSS3** - Modern styling with CSS Grid, Flexbox, and custom properties
- **JavaScript (ES6+)** - Interactive functionality and animations
- **Font Awesome** - Icons and symbols
- **Google Fonts** - Typography (Inter, JetBrains Mono)

## 🎨 Color Palette

```css
/* AI-Focused Brand Colors */
--primary-color: #0175C2;      /* Tech Blue */
--primary-dark: #02569B;       /* Darker Blue */
--primary-light: #54C5F8;      /* Light Blue */
--accent-color: #40E0D0;       /* AI Turquoise */

/* Dark Theme Colors */
--bg-primary: #0D1117;         /* Main Background */
--bg-secondary: #161B22;       /* Card Background */
--bg-tertiary: #21262D;        /* Surface Color */
--text-primary: #F0F6FC;       /* Primary Text */
--text-secondary: #8B949E;     /* Secondary Text */
```

## 🚀 Getting Started

### Prerequisites
- A modern web browser (Chrome, Firefox, Safari, Edge)
- A local web server (optional, for development)

### Installation

1. **Clone or download** the project files
2. **Add your images** to the `assets/images/` directory:
   - `developer-avatar.jpg` (300x300px)
   - `about-photo.jpg` (300x400px)
   - `project1.jpg` through `project6.jpg` (400x250px each)
   - `og-image.jpg` (1200x630px)

3. **Customize the content** in `index.html`:
   - Update personal information
   - Modify project details
   - Adjust skills and experience
   - Update contact information

4. **Open `index.html`** in your web browser or serve it using a local web server

### Local Development Server

For development, you can use any local server:

```bash
# Using Python 3
python -m http.server 8000

# Using Node.js (http-server)
npx http-server

# Using PHP
php -S localhost:8000
```

Then visit `http://localhost:8000` in your browser.

## ⚙️ Customization

### Personal Information
Edit the following sections in `index.html`:
- Hero section name and AI development description
- About section content and AI tool statistics
- AI tools and technology proficiency levels
- AI-powered project details and links
- AI development experience timeline
- Contact information

### Styling
Modify `css/style.css` to customize:
- Color scheme (CSS custom properties at the top)
- Typography and spacing
- Layout and responsive breakpoints
- Animation timings and effects

### Functionality
Update `js/main.js` to modify:
- AI-focused typing animation texts
- AI project data and modal content
- Form submission handling
- Animation triggers and effects

## 📱 Responsive Design

The portfolio is fully responsive with breakpoints at:
- **Mobile**: 320px - 768px
- **Tablet**: 768px - 1024px
- **Desktop**: 1024px+

Key responsive features:
- Collapsible navigation menu
- Stacked layouts on mobile
- Optimized typography scaling
- Touch-friendly interactive elements

## 🎯 Browser Support

- Chrome 60+
- Firefox 60+
- Safari 12+
- Edge 79+

## 📈 Performance Features

- **Lazy Loading** for images and animations
- **Debounced Scroll Events** for smooth performance
- **Optimized Animations** using transform and opacity
- **Efficient DOM Queries** with caching
- **Reduced Motion Support** for accessibility

## 🔧 Customization Guide

### Adding New AI Projects

1. Add AI project data to the `projectData` object in `js/main.js`
2. Add a new project card in the HTML with appropriate AI category
3. Include the project image in `assets/images/`

### Modifying AI Skills

1. Update the AI tools and skills sections in `index.html`
2. Adjust the `data-width` attributes for progress bars
3. Modify skill categories (AI Tools, Web/Mobile Tech, Development Tools)

### Changing Colors

Update the CSS custom properties in `css/style.css`:

```css
:root {
    --primary-color: #your-color;
    --primary-dark: #your-dark-color;
    --primary-light: #your-light-color;
}
```

## 📄 License

This project is open source and available under the [MIT License](LICENSE).

## 🤝 Contributing

Contributions, issues, and feature requests are welcome! Feel free to check the issues page.

## 📞 Support

If you have any questions or need help customizing the portfolio, feel free to reach out or create an issue.

---

**Built with ❤️ for AI-Powered Developers**

Showcase your AI-powered development skills and modern technology expertise with this professional portfolio template.