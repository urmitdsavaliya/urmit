// ===== ADVANCED ANIMATIONS JAVASCRIPT =====

// Animation utilities and advanced effects
class AnimationController {
    constructor() {
        this.observers = new Map();
        this.animationQueue = [];
        this.isAnimating = false;
        this.init();
    }

    init() {
        this.setupIntersectionObservers();
        this.setupScrollAnimations();
        this.setupHoverEffects();
        this.setupParallaxEffects();
    }

    // ===== INTERSECTION OBSERVER ANIMATIONS =====
    setupIntersectionObservers() {
        const observerOptions = {
            threshold: [0.1, 0.3, 0.5, 0.7],
            rootMargin: '0px 0px -50px 0px'
        };

        // Fade in animations
        const fadeInObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    this.animateFadeIn(entry.target, entry.intersectionRatio);
                }
            });
        }, observerOptions);

        // Slide in animations
        const slideInObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    this.animateSlideIn(entry.target);
                }
            });
        }, observerOptions);

        // Scale in animations
        const scaleInObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    this.animateScaleIn(entry.target);
                }
            });
        }, observerOptions);

        // Observe elements
        document.querySelectorAll('.fade-in-up, .fade-in-left, .fade-in-right').forEach(el => {
            fadeInObserver.observe(el);
        });

        document.querySelectorAll('.slide-in-left, .slide-in-right').forEach(el => {
            slideInObserver.observe(el);
        });

        document.querySelectorAll('.scale-in-center').forEach(el => {
            scaleInObserver.observe(el);
        });

        this.observers.set('fadeIn', fadeInObserver);
        this.observers.set('slideIn', slideInObserver);
        this.observers.set('scaleIn', scaleInObserver);
    }

    // ===== ANIMATION METHODS =====
    animateFadeIn(element, ratio) {
        if (element.classList.contains('animated')) return;
        
        element.style.opacity = Math.min(ratio * 2, 1);
        element.style.transform = `translateY(${Math.max(30 - (ratio * 60), 0)}px)`;
        
        if (ratio > 0.3) {
            element.classList.add('animated');
            element.style.opacity = '1';
            element.style.transform = 'translateY(0)';
        }
    }

    animateSlideIn(element) {
        if (element.classList.contains('animated')) return;
        
        element.classList.add('animated');
        const direction = element.classList.contains('slide-in-left') ? 'left' : 'right';
        const translateX = direction === 'left' ? '-50px' : '50px';
        
        element.style.transform = `translateX(${translateX})`;
        element.style.opacity = '0';
        
        requestAnimationFrame(() => {
            element.style.transition = 'transform 0.6s ease, opacity 0.6s ease';
            element.style.transform = 'translateX(0)';
            element.style.opacity = '1';
        });
    }

    animateScaleIn(element) {
        if (element.classList.contains('animated')) return;
        
        element.classList.add('animated');
        element.style.transform = 'scale(0.8)';
        element.style.opacity = '0';
        
        requestAnimationFrame(() => {
            element.style.transition = 'transform 0.6s ease, opacity 0.6s ease';
            element.style.transform = 'scale(1)';
            element.style.opacity = '1';
        });
    }

    // ===== SCROLL ANIMATIONS =====
    setupScrollAnimations() {
        let ticking = false;
        
        const updateScrollAnimations = () => {
            const scrollY = window.pageYOffset;
            const windowHeight = window.innerHeight;
            
            // Parallax backgrounds
            this.updateParallaxElements(scrollY);
            
            // Progress indicators
            this.updateScrollProgress(scrollY);
            
            // Floating elements
            this.updateFloatingElements(scrollY);
            
            ticking = false;
        };

        window.addEventListener('scroll', () => {
            if (!ticking) {
                requestAnimationFrame(updateScrollAnimations);
                ticking = true;
            }
        });
    }

    updateParallaxElements(scrollY) {
        const parallaxElements = document.querySelectorAll('[data-parallax]');
        
        parallaxElements.forEach(element => {
            const speed = parseFloat(element.dataset.parallax) || 0.5;
            const yPos = -(scrollY * speed);
            element.style.transform = `translateY(${yPos}px)`;
        });
    }

    updateScrollProgress(scrollY) {
        const documentHeight = document.documentElement.scrollHeight - window.innerHeight;
        const progress = (scrollY / documentHeight) * 100;
        
        // Update any progress indicators
        const progressBars = document.querySelectorAll('.scroll-progress');
        progressBars.forEach(bar => {
            bar.style.width = `${progress}%`;
        });
    }

    updateFloatingElements(scrollY) {
        const floatingElements = document.querySelectorAll('.floating');
        
        floatingElements.forEach((element, index) => {
            const speed = 0.5 + (index * 0.1);
            const yPos = Math.sin(scrollY * 0.01 + index) * 10;
            element.style.transform = `translateY(${yPos}px)`;
        });
    }

    // ===== HOVER EFFECTS =====
    setupHoverEffects() {
        // Magnetic effect for buttons
        this.setupMagneticEffect();
        
        // Tilt effect for cards
        this.setupTiltEffect();
        
        // Glow effect for interactive elements
        this.setupGlowEffect();
    }

    setupMagneticEffect() {
        const magneticElements = document.querySelectorAll('.btn, .project-link, .social-link');
        
        magneticElements.forEach(element => {
            element.addEventListener('mousemove', (e) => {
                const rect = element.getBoundingClientRect();
                const x = e.clientX - rect.left - rect.width / 2;
                const y = e.clientY - rect.top - rect.height / 2;
                
                element.style.transform = `translate(${x * 0.1}px, ${y * 0.1}px)`;
            });
            
            element.addEventListener('mouseleave', () => {
                element.style.transform = 'translate(0, 0)';
            });
        });
    }

    setupTiltEffect() {
        const tiltElements = document.querySelectorAll('.project-card, .skill-category, .timeline-content');
        
        tiltElements.forEach(element => {
            element.addEventListener('mousemove', (e) => {
                const rect = element.getBoundingClientRect();
                const centerX = rect.left + rect.width / 2;
                const centerY = rect.top + rect.height / 2;
                
                const deltaX = (e.clientX - centerX) / (rect.width / 2);
                const deltaY = (e.clientY - centerY) / (rect.height / 2);
                
                const rotateX = deltaY * -5;
                const rotateY = deltaX * 5;
                
                element.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg)`;
            });
            
            element.addEventListener('mouseleave', () => {
                element.style.transform = 'perspective(1000px) rotateX(0deg) rotateY(0deg)';
            });
        });
    }

    setupGlowEffect() {
        const glowElements = document.querySelectorAll('.nav-link, .filter-btn, .social-link');
        
        glowElements.forEach(element => {
            element.addEventListener('mouseenter', () => {
                element.style.boxShadow = '0 0 20px rgba(1, 117, 194, 0.4)';
            });
            
            element.addEventListener('mouseleave', () => {
                element.style.boxShadow = '';
            });
        });
    }

    // ===== PARALLAX EFFECTS =====
    setupParallaxEffects() {
        // Add parallax data attributes to elements
        const heroBackground = document.querySelector('.hero-background');
        if (heroBackground) {
            heroBackground.setAttribute('data-parallax', '0.3');
        }
        
        // Create floating shapes
        this.createFloatingShapes();
    }

    createFloatingShapes() {
        const shapesContainer = document.createElement('div');
        shapesContainer.className = 'floating-shapes';
        shapesContainer.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: -1;
        `;
        
        document.body.appendChild(shapesContainer);
        
        // Create multiple floating shapes
        for (let i = 0; i < 5; i++) {
            this.createFloatingShape(shapesContainer, i);
        }
    }

    createFloatingShape(container, index) {
        const shape = document.createElement('div');
        shape.className = 'floating-shape';
        
        const size = Math.random() * 100 + 50;
        const left = Math.random() * 100;
        const animationDuration = Math.random() * 10 + 10;
        const delay = Math.random() * 5;
        
        shape.style.cssText = `
            position: absolute;
            width: ${size}px;
            height: ${size}px;
            background: linear-gradient(45deg, rgba(1, 117, 194, 0.1), rgba(84, 197, 248, 0.1));
            border-radius: 50%;
            left: ${left}%;
            top: 100%;
            animation: floatUp ${animationDuration}s linear infinite;
            animation-delay: ${delay}s;
        `;
        
        container.appendChild(shape);
        
        // Remove and recreate shape after animation
        setTimeout(() => {
            if (shape.parentNode) {
                shape.parentNode.removeChild(shape);
                this.createFloatingShape(container, index);
            }
        }, (animationDuration + delay) * 1000);
    }

    // ===== STAGGER ANIMATIONS =====
    staggerAnimation(elements, animationClass, delay = 100) {
        elements.forEach((element, index) => {
            setTimeout(() => {
                element.classList.add(animationClass);
            }, index * delay);
        });
    }

    // ===== MORPHING ANIMATIONS =====
    morphElement(element, targetStyles, duration = 300) {
        return new Promise(resolve => {
            const startStyles = window.getComputedStyle(element);
            const startTime = performance.now();
            
            const animate = (currentTime) => {
                const elapsed = currentTime - startTime;
                const progress = Math.min(elapsed / duration, 1);
                
                // Apply easing function
                const easedProgress = this.easeInOutCubic(progress);
                
                // Interpolate styles
                Object.keys(targetStyles).forEach(property => {
                    const startValue = parseFloat(startStyles[property]) || 0;
                    const targetValue = parseFloat(targetStyles[property]);
                    const currentValue = startValue + (targetValue - startValue) * easedProgress;
                    
                    element.style[property] = currentValue + (targetStyles[property].includes('px') ? 'px' : '');
                });
                
                if (progress < 1) {
                    requestAnimationFrame(animate);
                } else {
                    resolve();
                }
            };
            
            requestAnimationFrame(animate);
        });
    }

    // ===== EASING FUNCTIONS =====
    easeInOutCubic(t) {
        return t < 0.5 ? 4 * t * t * t : (t - 1) * (2 * t - 2) * (2 * t - 2) + 1;
    }

    easeOutBounce(t) {
        if (t < 1 / 2.75) {
            return 7.5625 * t * t;
        } else if (t < 2 / 2.75) {
            return 7.5625 * (t -= 1.5 / 2.75) * t + 0.75;
        } else if (t < 2.5 / 2.75) {
            return 7.5625 * (t -= 2.25 / 2.75) * t + 0.9375;
        } else {
            return 7.5625 * (t -= 2.625 / 2.75) * t + 0.984375;
        }
    }

    // ===== CHAIN ANIMATIONS =====
    chainAnimations(animations) {
        return animations.reduce((promise, animation) => {
            return promise.then(() => animation());
        }, Promise.resolve());
    }

    // ===== CLEANUP =====
    destroy() {
        this.observers.forEach(observer => observer.disconnect());
        this.observers.clear();
        
        // Remove event listeners
        window.removeEventListener('scroll', this.updateScrollAnimations);
        
        // Clear animation queue
        this.animationQueue = [];
    }
}

// ===== SPECIALIZED ANIMATIONS =====

// Text reveal animation
class TextRevealAnimation {
    constructor(element, options = {}) {
        this.element = element;
        this.options = {
            duration: 1000,
            delay: 0,
            easing: 'ease-out',
            ...options
        };
        this.init();
    }

    init() {
        const text = this.element.textContent;
        this.element.innerHTML = '';
        
        // Wrap each character in a span
        [...text].forEach((char, index) => {
            const span = document.createElement('span');
            span.textContent = char === ' ' ? '\u00A0' : char;
            span.style.cssText = `
                display: inline-block;
                opacity: 0;
                transform: translateY(20px);
                transition: opacity 0.3s ease, transform 0.3s ease;
                transition-delay: ${index * 50}ms;
            `;
            this.element.appendChild(span);
        });
    }

    reveal() {
        const spans = this.element.querySelectorAll('span');
        spans.forEach(span => {
            span.style.opacity = '1';
            span.style.transform = 'translateY(0)';
        });
    }
}

// Counter animation
class CounterAnimation {
    constructor(element, targetValue, options = {}) {
        this.element = element;
        this.targetValue = targetValue;
        this.options = {
            duration: 2000,
            easing: 'easeOutCubic',
            suffix: '',
            ...options
        };
    }

    animate() {
        const startTime = performance.now();
        const startValue = 0;
        
        const updateCounter = (currentTime) => {
            const elapsed = currentTime - startTime;
            const progress = Math.min(elapsed / this.options.duration, 1);
            
            const easedProgress = this.easeOutCubic(progress);
            const currentValue = Math.floor(startValue + (this.targetValue - startValue) * easedProgress);
            
            this.element.textContent = currentValue + this.options.suffix;
            
            if (progress < 1) {
                requestAnimationFrame(updateCounter);
            }
        };
        
        requestAnimationFrame(updateCounter);
    }

    easeOutCubic(t) {
        return 1 - Math.pow(1 - t, 3);
    }
}

// Typewriter effect
class TypewriterEffect {
    constructor(element, texts, options = {}) {
        this.element = element;
        this.texts = Array.isArray(texts) ? texts : [texts];
        this.options = {
            typeSpeed: 100,
            deleteSpeed: 50,
            pauseTime: 2000,
            loop: true,
            cursor: '|',
            ...options
        };
        this.currentTextIndex = 0;
        this.currentCharIndex = 0;
        this.isDeleting = false;
        this.init();
    }

    init() {
        if (this.options.cursor) {
            this.cursorElement = document.createElement('span');
            this.cursorElement.textContent = this.options.cursor;
            this.cursorElement.style.animation = 'blink 1s infinite';
            this.element.appendChild(this.cursorElement);
        }
        this.type();
    }

    type() {
        const currentText = this.texts[this.currentTextIndex];
        const textElement = this.element.firstChild || this.element;
        
        if (this.isDeleting) {
            textElement.textContent = currentText.substring(0, this.currentCharIndex - 1);
            this.currentCharIndex--;
        } else {
            textElement.textContent = currentText.substring(0, this.currentCharIndex + 1);
            this.currentCharIndex++;
        }
        
        let typeSpeed = this.isDeleting ? this.options.deleteSpeed : this.options.typeSpeed;
        
        if (!this.isDeleting && this.currentCharIndex === currentText.length) {
            typeSpeed = this.options.pauseTime;
            this.isDeleting = true;
        } else if (this.isDeleting && this.currentCharIndex === 0) {
            this.isDeleting = false;
            this.currentTextIndex = (this.currentTextIndex + 1) % this.texts.length;
            typeSpeed = 500;
        }
        
        setTimeout(() => this.type(), typeSpeed);
    }
}

// ===== INITIALIZE ANIMATIONS =====
document.addEventListener('DOMContentLoaded', () => {
    // Initialize main animation controller
    window.animationController = new AnimationController();
    
    // Initialize text reveal animations
    document.querySelectorAll('.text-reveal').forEach(element => {
        new TextRevealAnimation(element);
    });
    
    // Initialize counter animations
    document.querySelectorAll('[data-counter]').forEach(element => {
        const targetValue = parseInt(element.dataset.counter);
        const suffix = element.dataset.suffix || '';
        new CounterAnimation(element, targetValue, { suffix });
    });
    
    // Add floating animation keyframes
    const style = document.createElement('style');
    style.textContent = `
        @keyframes floatUp {
            0% {
                transform: translateY(100vh) rotate(0deg);
                opacity: 0;
            }
            10% {
                opacity: 0.3;
            }
            90% {
                opacity: 0.3;
            }
            100% {
                transform: translateY(-100px) rotate(360deg);
                opacity: 0;
            }
        }
        
        @keyframes blink {
            0%, 50% { opacity: 1; }
            51%, 100% { opacity: 0; }
        }
    `;
    document.head.appendChild(style);
});

// ===== PERFORMANCE MONITORING =====
class PerformanceMonitor {
    constructor() {
        this.frameCount = 0;
        this.lastTime = performance.now();
        this.fps = 0;
        this.monitor();
    }

    monitor() {
        const currentTime = performance.now();
        this.frameCount++;
        
        if (currentTime - this.lastTime >= 1000) {
            this.fps = Math.round((this.frameCount * 1000) / (currentTime - this.lastTime));
            this.frameCount = 0;
            this.lastTime = currentTime;
            
            // Log performance if FPS drops below 30
            if (this.fps < 30) {
                console.warn(`Low FPS detected: ${this.fps}`);
            }
        }
        
        requestAnimationFrame(() => this.monitor());
    }
}

// Initialize performance monitoring in development
if (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1') {
    new PerformanceMonitor();
}

// Export for use in other files
window.AnimationUtils = {
    AnimationController,
    TextRevealAnimation,
    CounterAnimation,
    TypewriterEffect,
    PerformanceMonitor
};